How to use:

1) Open the text document you want.
2) Copy the entire command with CTRL+C
3) Go into minecraft (also if the text document name has 1.15 or
1.16 in it then go onto those versions for it to work. If it has a + on it,
that means it might work on the new versions)
4) Paste the command into a command block and activate the command
block.
5) Done!

If there is a problem, message Skelebrine#0034 on Discord. I will
work on a fix.

If you want to suggest something to be created, contact me on Discord.
Message me the idea, name of the item (sometimes not possible).
If it is a mob or something, tell me the drops from it or the weapons
or enchants.

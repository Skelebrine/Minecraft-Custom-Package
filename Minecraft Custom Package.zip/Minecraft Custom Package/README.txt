How to use:

1) Open the text document you want.
2) Copy the entire command with CTRL+C
3) Go into minecraft (also if the text document name has 1.15 or
1.16 in it then go onto those versions for it to work. If it has a + on it,
that means it might work on the new versions)
4) Paste the command into a command block and activate the command
block.
5) Done!